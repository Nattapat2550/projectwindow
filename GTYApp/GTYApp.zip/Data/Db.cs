﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Text;

namespace GTYApp.Data
{
    public static class Db
    {
        private static string? _cs;
        public static string ConnectionString => _cs ??= BuildConnectionString();

        private static string BuildConnectionString()
        {
            // อ่านค่าจาก appsettings.json
            var raw = Utils.AppConfig.GetString("Database", "Url");
            if (string.IsNullOrWhiteSpace(raw))
                throw new ArgumentException("Database.Url missing in appsettings.json");
            // ถ้าเป็น key=value อยู่แล้ว ก็ใช้ได้เลย
            if (raw.Contains("Host=", StringComparison.OrdinalIgnoreCase) ||
                raw.Contains("Server=", StringComparison.OrdinalIgnoreCase))
                return raw;

            // รองรับ URL แบบ postgresql:// หรือ postgres://
            if (raw.StartsWith("postgres://", StringComparison.OrdinalIgnoreCase) ||
                raw.StartsWith("postgresql://", StringComparison.OrdinalIgnoreCase))
            {
                var uri = new Uri(raw);

                // user:pass
                var userInfo = uri.UserInfo.Split(':', 2, StringSplitOptions.None);
                var username = Uri.UnescapeDataString(userInfo[0]);
                var password = userInfo.Length > 1 ? Uri.UnescapeDataString(userInfo[1]) : "";

                // db name (ตัด '/')
                var database = uri.AbsolutePath.TrimStart('/');

                var builder = new NpgsqlConnectionStringBuilder
                {
                    Host = uri.Host,
                    Port = uri.IsDefaultPort ? 5432 : uri.Port,
                    Username = username,
                    Password = password,
                    Database = database,
                    SslMode = SslMode.Require, // Render ต้องใช้ SSL
                    // TrustServerCertificate ถูก deprecate ใน Npgsql 9 — ไม่ต้องตั้ง
                    // ถ้าองค์กรต้องการ validate cert เต็ม ให้เพิ่ม Root Certificate ตาม policy ของคุณ
                    Timeout = 15,
                    CommandTimeout = 30
                };

                // รองรับ querystring เพิ่มเติมใน URL (เช่น ?sslmode=require)
                // Npgsql ไม่มี merge อัตโนมัติจาก Query จึงข้ามไป ถ้าต้องการให้เพิ่มเองใน appsettings เป็นแบบ key=value

                return builder.ToString();
            }

            // รูปแบบไม่รู้จัก → โยน exception บอก config
            throw new ArgumentException("Invalid Database.Url format in appsettings.json. Expected key=value pairs or a postgresql:// URL.");
        }

        public static NpgsqlConnection GetOpenConnection()
        {
            var conn = new NpgsqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        public static void Initialize()
        {
            using var conn = GetOpenConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT 1";
            cmd.ExecuteScalar();
        }
    }
}
