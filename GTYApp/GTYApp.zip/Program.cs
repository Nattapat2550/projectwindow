using GTYApp.Utils;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GTYApp
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            Application.ThreadException += (s, ex) =>
            {
                MessageBox.Show("UI Error:\n" + ex.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
            AppDomain.CurrentDomain.UnhandledException += (s, ex) =>
            {
                var e = ex.ExceptionObject as Exception;
                MessageBox.Show("App Error:\n" + e?.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            // เช็ค Config
            try
            {
                AppConfig.LoadOrThrow();
                Services.PureApiClient.ConfigureFromAppSettings();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Config Error:\n" + ex.Message, "Start-up Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // ⚠️ ปิดระบบ Auto-login ไว้ชั่วคราว เพื่อไม่ให้โปรแกรมไปค้างรอเซิร์ฟเวอร์
            /*
            try
            {
                var token = CryptoStorage.TryRestoreRememberToken();
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var resumeTask = Task.Run(() => Services.AuthService.TryResumeSessionAsync(token!));
                    resumeTask.Wait(TimeSpan.FromSeconds(3));
                }
            }
            catch { }
            */

            // แสดง MessageBox เพื่อยืนยันว่าโค้ดมารันถึงตรงนี้แล้ว
            // MessageBox.Show("กำลังจะเปิดหน้าจอหลัก..."); 

            Application.Run(new AppContextEx());
        }
    }
}