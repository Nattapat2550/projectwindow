﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace GTYApp.Utils
{
    public static class CryptoStorage
    {
        private static string FilePath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                         "GTYApp", "remember.bin");

        public static void SaveRememberToken(string token)
        {
            var dir = Path.GetDirectoryName(FilePath)!;
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            var data = Encoding.UTF8.GetBytes(token);
            var enc = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);
            File.WriteAllBytes(FilePath, enc);
        }

        public static string? TryRestoreRememberToken()
        {
            if (!File.Exists(FilePath)) return null;
            try
            {
                var enc = File.ReadAllBytes(FilePath);
                var data = ProtectedData.Unprotect(enc, null, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(data);
            }
            catch { return null; }
        }

        public static void Clear() { try { if (File.Exists(FilePath)) File.Delete(FilePath); } catch { } }
    }
}
