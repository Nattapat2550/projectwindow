﻿using System;
using System.Windows.Forms;

namespace GTYApp.Utils
{
    public sealed class AppContextEx : ApplicationContext
    {
        public static AppContextEx? Instance { get; private set; }

        public AppContextEx()
        {
            Instance = this;
            NavigateByRole();
        }

        public void Navigate(Form next)
        {
            if (next == null) return;

            var oldForm = MainForm;
            MainForm = next;

            if (MainForm.StartPosition == FormStartPosition.WindowsDefaultLocation)
                MainForm.StartPosition = FormStartPosition.CenterScreen;

            MainForm.Show();

            if (oldForm != null && !oldForm.IsDisposed)
            {
                oldForm.Close();
                oldForm.Dispose();
            }
        }

        public void NavigateByRole()
        {
            try
            {
                if (Session.CurrentUser is null)
                    Navigate(new Forms.HomePublicForm());
                else if (Session.CurrentUser.Role?.ToLowerInvariant() == "admin")
                    Navigate(new Forms.AdminForm());
                else
                    Navigate(new Forms.MainForm());
            }
            catch (Exception ex)
            {
                // ดัก Error เผื่อว่าหน้า HomePublic หรือ MainForm พังตอนโหลด
                MessageBox.Show("ไม่สามารถเปิดหน้าจอได้:\n" + ex.Message, "UI Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}