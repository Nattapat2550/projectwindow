﻿using GTYApp.Utils;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace GTYApp.Services
{
    public static class PureApiClient
    {
        private static readonly HttpClient _http = new();
        private static string _baseUrl = "";
        private static string _apiKey = "";

        private static readonly JsonSerializerOptions _json = new()
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true
        };

        public static void ConfigureFromAppSettings() => EnsureConfigured();

        private static void EnsureConfigured()
        {
            var baseUrl = AppConfig.GetString("ApiPure", "BaseUrl")?.Trim();
            var apiKey = AppConfig.GetString("ApiPure", "ApiKey")?.Trim();

            if (string.IsNullOrWhiteSpace(baseUrl)) baseUrl = "https://pure-api-aprd.onrender.com/api";
            if (string.IsNullOrWhiteSpace(apiKey)) apiKey = "windows-key-123";

            baseUrl = baseUrl.TrimEnd('/');

            if (_baseUrl == baseUrl && _apiKey == apiKey) return;

            _baseUrl = baseUrl;
            _apiKey = apiKey;

            _http.BaseAddress = new Uri(_baseUrl + "/");
            _http.DefaultRequestHeaders.Accept.Clear();
            _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            _http.DefaultRequestHeaders.Remove("x-api-key");
            _http.DefaultRequestHeaders.TryAddWithoutValidation("x-api-key", _apiKey);
        }

        private static string NormalizePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("path is required", nameof(path));
            path = path.Trim();

            if (path.StartsWith("/api/", StringComparison.OrdinalIgnoreCase)) path = path[5..];
            else if (path.StartsWith("api/", StringComparison.OrdinalIgnoreCase)) path = path[4..];

            return path.TrimStart('/');
        }

        // เมธอดดั้งเดิม (คงไว้ไม่ให้โค้ดส่วนอื่นพัง)
        public static JsonElement Send(HttpMethod method, string path, object? body = null, bool withJwt = false)
        {
            return SendAsync(method, path, body, withJwt).GetAwaiter().GetResult();
        }

        // 🌟 [เพิ่มใหม่] เมธอดแบบ Async สำหรับไม่ให้ UI ค้าง
        public static async Task<JsonElement> SendAsync(HttpMethod method, string path, object? body = null, bool withJwt = false)
        {
            EnsureConfigured();
            var rel = NormalizePath(path);

            using var req = new HttpRequestMessage(method, rel);
            req.Headers.Remove("x-api-key");
            req.Headers.TryAddWithoutValidation("x-api-key", _apiKey);

            if (withJwt)
            {
                var jwt = Session.Jwt;
                if (string.IsNullOrWhiteSpace(jwt)) throw new Exception("JWT_MISSING");
                req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", jwt);
            }

            if (body is not null)
            {
                var json = JsonSerializer.Serialize(body, _json);
                req.Content = new StringContent(json, Encoding.UTF8, "application/json");
            }

            using var resp = await _http.SendAsync(req);
            var text = (await resp.Content.ReadAsStringAsync()) ?? "";

            var trimmed = text.TrimStart();
            var looksJson = trimmed.StartsWith('{') || trimmed.StartsWith('[');
            var mediaType = resp.Content.Headers.ContentType?.MediaType ?? "";

            if (!looksJson && !mediaType.Contains("json", StringComparison.OrdinalIgnoreCase))
            {
                var head = text.Length > 250 ? string.Concat(text.AsSpan(0, 250), "...") : text;
                throw new Exception($"Non-JSON response (HTTP {(int)resp.StatusCode}). First chars: {head}");
            }

            try
            {
                using var doc = JsonDocument.Parse(text, new JsonDocumentOptions
                {
                    AllowTrailingCommas = true,
                    CommentHandling = JsonCommentHandling.Skip
                });

                var root = doc.RootElement;

                if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("ok", out var okEl))
                {
                    if (okEl.ValueKind == JsonValueKind.True)
                    {
                        if (root.TryGetProperty("data", out var data)) return data.Clone();
                        return root.Clone();
                    }

                    var msg = "Request failed";
                    if (root.TryGetProperty("error", out var err) && err.ValueKind == JsonValueKind.Object)
                    {
                        if (err.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String) msg = m.GetString() ?? msg;
                        else if (err.TryGetProperty("details", out var d) && d.ValueKind == JsonValueKind.String) msg = d.GetString() ?? msg;
                    }
                    throw new Exception(msg);
                }

                if (!resp.IsSuccessStatusCode)
                    throw new Exception($"HTTP {(int)resp.StatusCode}: {text}");

                return root.Clone();
            }
            catch (JsonException)
            {
                var head = text.Length > 250 ? string.Concat(text.AsSpan(0, 250), "...") : text;
                throw new Exception($"Invalid JSON (HTTP {(int)resp.StatusCode}). First chars: {head}");
            }
        }
    }
}
