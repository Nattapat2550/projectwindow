﻿using GTYApp.Utils;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using GTYApp.Models;

namespace GTYApp.Services
{
    public static class UserService
    {
        public static User? GetMe()
        {
            try
            {
                var data = PureApiClient.Send(HttpMethod.Get, "/users/me", withJwt: true);
                return ParseUserMe(data);
            }
            catch
            {
                return null;
            }
        }

        public static bool UpdateUsername(int _, string newUsername)
        {
            return PatchMe(username: newUsername, profilePictureUrl: null);
        }

        public static bool UpdateProfilePicture(int _, string dataUrl)
        {
            return PatchMe(username: null, profilePictureUrl: dataUrl);
        }

        public static bool DeleteAccount(int id)
        {
            try
            {
                _ = PureApiClient.Send(HttpMethod.Post, "/internal/delete-user", new { id });
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<User> GetAllUsers()
        {
            var list = new List<User>();
            if (!Session.IsAdmin) return list;

            try
            {
                var data = PureApiClient.Send(HttpMethod.Get, "/internal/admin/users");
                if (data.ValueKind != JsonValueKind.Array) return list;

                foreach (var u in data.EnumerateArray())
                {
                    list.Add(new User
                    {
                        Id = u.GetProperty("id").GetInt32(),
                        Email = u.GetProperty("email").GetString() ?? "",
                        Username = u.TryGetProperty("username", out var un) && un.ValueKind != JsonValueKind.Null ? un.GetString() : null,
                        Role = u.TryGetProperty("role", out var role) ? (role.GetString() ?? "user") : "user",
                        PasswordHash = u.TryGetProperty("password_hash", out var ph) && ph.ValueKind != JsonValueKind.Null ? ph.GetString() : null,
                        IsEmailVerified = u.TryGetProperty("is_email_verified", out var v) && v.ValueKind == JsonValueKind.True,
                        OauthProvider = u.TryGetProperty("oauth_provider", out var pr) && pr.ValueKind != JsonValueKind.Null ? pr.GetString() : null,
                        ProfilePictureUrl = u.TryGetProperty("profile_picture_url", out var pp) && pp.ValueKind != JsonValueKind.Null ? pp.GetString() : null,
                        OauthId = u.TryGetProperty("oauth_id", out var oid) && oid.ValueKind != JsonValueKind.Null ? oid.GetString() : null,
                    });
                }
            }
            catch { }

            return list;
        }

        public static bool UpdateUser(User u)
        {
            if (!Session.IsAdmin) return false;

            try
            {
                _ = PureApiClient.Send(HttpMethod.Patch, $"/users/{u.Id}/role", new { role = u.Role }, withJwt: true);

                _ = PureApiClient.Send(HttpMethod.Post, "/internal/admin/users/update", new
                {
                    id = u.Id,
                    username = u.Username,
                    profile_picture_url = u.ProfilePictureUrl
                });

                return true;
            }
            catch
            {
                return false;
            }
        }

        private static bool PatchMe(string? username, string? profilePictureUrl)
        {
            try
            {
                _ = PureApiClient.Send(HttpMethod.Patch, "/users/me", new
                {
                    username,
                    profile_picture_url = profilePictureUrl
                }, withJwt: true);

                var me = GetMe();
                if (me is not null)
                    Session.CurrentUser = me;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private static User ParseUserMe(JsonElement me)
        {
            return new User
            {
                Id = me.GetProperty("id").GetInt32(),
                Username = me.TryGetProperty("username", out var un) && un.ValueKind != JsonValueKind.Null ? un.GetString() : null,
                Email = me.GetProperty("email").GetString() ?? "",
                Role = me.TryGetProperty("role", out var role) ? (role.GetString() ?? "user") : "user",
                ProfilePictureUrl = me.TryGetProperty("profile_picture_url", out var pp) && pp.ValueKind != JsonValueKind.Null ? pp.GetString() : null,
                IsEmailVerified = me.TryGetProperty("is_email_verified", out var v) && v.ValueKind == JsonValueKind.True
            };
        }
    }
}
